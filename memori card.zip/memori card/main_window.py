from PyQt5.QtCore import*
from PyQt5.QtWidgets import*

win=QWidget()
win.resize(900,800)

btn_menu=QPushButton("Menu")
btn_sleep=QPushButton("Відпочити")

sp_minutes=QSpinBox()
sp_minutes.setValue(30)

lb_min=QLabel("хвилини")

btn_ans=QPushButton("Відповісти")
Lb_qst=QLabel("")

RadioGroupBox=QGroupBox("Варіанти відповідей")

RadioGroup=QButtonGroup()

rbtn_1=QRadioButton("")
rbtn_2=QRadioButton("")
rbtn_3=QRadioButton("")
rbtn_4=QRadioButton("")

RadioGroup.addButton(rbtn_1)
RadioGroup.addButton(rbtn_2)
RadioGroup.addButton(rbtn_3)
RadioGroup.addButton(rbtn_4)

AnsGroupBox=QGroupBox("Результат тесту")

lb_Result=QLabel("")
ld_Correct=QLabel("")

row_ans1=QHBoxLayout()
col_ans2=QVBoxLayout()
col_ans3=QVBoxLayout()

col_ans2.addWidget(rbtn_1)
col_ans2.addWidget(rbtn_2)
col_ans3.addWidget(rbtn_3)
col_ans3.addWidget(rbtn_4)

row_ans1.addLayout(col_ans2)
row_ans1.addLayout(col_ans3)

RadioGroupBox.setLayout(row_ans1)

Layout_res=QVBoxLayout()
Layout_res.addWidget(lb_Result=(Qt.AlignLeft | Qt.AlignTop))
Layout_res.addWidget(lb_Correct=Qt.AlignHCenter,stretch=2)

AnsGroupBox.setLayout(Layout_res)
AnsGroupBox.hide()

win.show()

