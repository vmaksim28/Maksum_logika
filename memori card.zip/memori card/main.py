from PyQt5.QtCore import*
from PyQt5.QtWidgets import*



app=QApplication([])

from main_window import*
from menu_window import*

app.exec_()